package com.example.noteit;


import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class DeckRepository {

    // below line is the create a variable
    // for dao and list for all notes.
    private Dao dao;
    private LiveData<List<DeckModal>> allCourses;

    // creating a constructor for our variables
    // and passing the variables to it.
    public DeckRepository(Application application) {
        DeckDatabase database = DeckDatabase.getInstance(application);
        dao = database.Dao();
        allCourses = dao.getAllCourses();
    }

    // creating a method to insert the data to our database.
    public void insert(DeckModal model) {
        new InsertCourseAsyncTask(dao).execute(model);
    }

    // creating a method to update data in database.
    public void update(DeckModal model) {
        new UpdateCourseAsyncTask(dao).execute(model);
    }

    // creating a method to delete the data in our database.
    public void delete(DeckModal model) {
        new DeleteCourseAsyncTask(dao).execute(model);
    }

    // below is the method to delete all the courses.
    public void deleteAllCourses() {
        new DeleteAllnotesAsyncTask(dao).execute();
    }

    // below method is to read all the courses.
    public LiveData<List<DeckModal>> getAllCourses() {
        return allCourses;
    }

    // we are creating a async task method to insert new note.
    private static class InsertCourseAsyncTask extends AsyncTask<DeckModal, Void, Void> {
        private Dao dao;

        private InsertCourseAsyncTask(Dao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(DeckModal... model) {
            // below line is use to insert our modal in dao.
            dao.insert(model[0]);
            return null;
        }
    }

    // we are creating a async task method to update our  note.
    private static class UpdateCourseAsyncTask extends AsyncTask<DeckModal, Void, Void> {
        private Dao dao;

        private UpdateCourseAsyncTask(Dao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(DeckModal... models) {
            // below line is use to update
            // our modal in dao.
            dao.update(models[0]);
            return null;
        }
    }

    // we are creating a async task method to delete note.
    private static class DeleteCourseAsyncTask extends AsyncTask<DeckModal, Void, Void> {
        private Dao dao;

        private DeleteCourseAsyncTask(Dao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(DeckModal... models) {
            // below line is use to delete
            // our note modal in dao.
            dao.delete(models[0]);
            return null;
        }
    }

    // we are creating a async task method to delete all courses.
    private static class DeleteAllnotesAsyncTask extends AsyncTask<Void, Void, Void> {
        private Dao dao;

        public DeleteAllnotesAsyncTask(Dao dao) {
        }

        private void DeleteAllnotesAsyncTask(Dao dao) {
            this.dao = dao;
        }
        @Override
        protected Void doInBackground(Void... voids) {
            // on below line calling method
            // to delete all courses.
            dao.deleteAllCourses();
            return null;
        }
    }

    public LiveData<List<DeckModal>> searchCourses(String query) {
        return dao.searchCourses("%" + query + "%");
    }


}

