package com.example.noteit;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.net.Uri;

import com.example.roomtutorial.R;


public class NewDeckActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 101;
    private static final int REQUEST_IMAGE_PICK = 102;
    private static final int PERMISSIONS_REQUEST = 100;
    private static final int CAMERA_PERMISSION_REQUEST = 104;
    private static final int STORAGE_PERMISSION_REQUEST = 103; // or any unique integer value


    public static final String EXTRA_ID = "com.example.roomtutorial.EXTRA_ID";
    public static final String EXTRA_NOTE_NAME = "com.example.roomtutorial.EXTRA_COURSE_NAME";
    public static final String EXTRA_DESCRIPTION = "com.example.roomtutorial.EXTRA_DESCRIPTION";
    public static final String EXTRA_DURATION = "com.example.roomtutorial.EXTRA_DURATION";
    public static final String EXTRA_IMAGE_PATH = "com.example.roomtutorial.EXTRA_IMAGE_PATH";

    private EditText deckNameEdt, deckDescEdt, deckDurationEdt;
    private Button courseBtn, btnTakePicture, btnUpload;
    private TextView locationTextView;

    private ImageView imageView;

    private Uri imageUri;

    //reference: ROOM database lab
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_course);

        deckNameEdt = findViewById(R.id.idEdtDeckName);
        deckDescEdt = findViewById(R.id.idEdtDeckDescription);
        locationTextView = findViewById(R.id.idLocationTextView);
        courseBtn = findViewById(R.id.idBtnSavenote);
        btnTakePicture = findViewById(R.id.btnTakePicture);
        btnUpload = findViewById(R.id.btnUpload);

        checkLocationPermission();


        // Check if there's data passed to this activity for editing an existing deck
        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_ID)) {
            deckNameEdt.setText(intent.getStringExtra(EXTRA_NOTE_NAME));
            deckDescEdt.setText(intent.getStringExtra(EXTRA_DESCRIPTION));
            // Set other fields if necessary, like deckDurationEdt
        }

        courseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCourse();
            }
        });

        btnUpload = findViewById(R.id.btnUpload);
        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        imageView = findViewById(R.id.idImageView);
        // Set the placeholder image (if not set in XML)
        imageView.setImageResource(R.drawable.ic_android_black_24dp);

        btnTakePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(NewDeckActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(NewDeckActivity.this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
                } else {
                    openCamera();
                }
            }
        });
    }

    private void saveCourse() {
        String courseName = deckNameEdt.getText().toString();
        String courseDescription = deckDescEdt.getText().toString();


        if (courseName.isEmpty() || courseDescription.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        saveCourse(courseName, courseDescription, ""); // Assuming imagePath is handled separately
    }

    private void openCamera() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera");
        imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);

        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } else {
            Toast.makeText(this, "No camera app available", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveCourse(String courseName, String courseDescription, String imagePath) {
        Intent data = new Intent();
        data.putExtra(EXTRA_NOTE_NAME, courseName);
        data.putExtra(EXTRA_DESCRIPTION, courseDescription);
        data.putExtra(EXTRA_IMAGE_PATH, imagePath); // If you are handling images

        int id = getIntent().getIntExtra(EXTRA_ID, -1);
        if (id != -1) {
            data.putExtra(EXTRA_ID, id);
        }

        setResult(RESULT_OK, data);
        Toast.makeText(this, "Note has been saved to Room Database.", Toast.LENGTH_SHORT).show();
        finish();
    }

    // ... other methods if needed ...
    private void checkStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_REQUEST);
        }
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Location permission granted
                getCurrentLocation();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == STORAGE_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Storage permission granted
                // You can now safely open the gallery if needed
            } else {
                Toast.makeText(this, "Storage permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }





    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST);
        } else {
            getCurrentLocation();
        }
    }




    private void getCurrentLocation() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        LocationListener locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                locationTextView.setText("Created note from: " + latitude + ", " + longitude);
            }

            // Implement other abstract methods...
        };

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }
    }



    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_IMAGE_PICK);
    }

    @Override

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            imageView.setImageURI(imageUri);
            // Directly use imageUri for imagePath
            saveCourse(deckNameEdt.getText().toString(), deckDescEdt.getText().toString(), imageUri.toString());
        }


    }



    // Method to convert Uri to a file path (if needed)
    private String getPathFromUri(Uri uri) {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);
        if (cursor == null) return null;
        int columnIndex = ((Cursor) cursor).getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String path = cursor.getString(columnIndex);
        cursor.close();
        return path;
    }
}
