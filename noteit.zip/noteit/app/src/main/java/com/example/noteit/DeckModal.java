package com.example.noteit;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "course_table")
public class DeckModal {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String deckName;
    private String deckDescription;

    public String getDeckDescription() {
        return deckDescription;
    }

    public void setDeckDescription(String deckDescription) {
        this.deckDescription = deckDescription;
    }

    // New attribute for image path
    private String imagePath;

    // Constructor updated to include the imagePath
    public DeckModal(String deckName, String deckDescription, String imagePath) {
        this.deckName = deckName;
        this.deckDescription = deckDescription;
        this.imagePath = imagePath;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDeckName() {
        return deckName;
    }

    public void setDeckName(String deckName) {
        this.deckName = deckName;
    }

    public String getdeckDescription() {
        return deckDescription;
    }

    public void setdeckDescription(String deckDescription) {
        this.deckDescription = deckDescription;
    }



    public String getImagePath() {
        return imagePath;
    }


   public void setImagePath(String imagePath) {
      this.imagePath = imagePath;
    }
}
