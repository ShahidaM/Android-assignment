package com.example.noteit;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.roomtutorial.R;

public class DeckRVAdapter extends ListAdapter<DeckModal, DeckRVAdapter.ViewHolder> {

    // creating a variable for on item click listener.
    private OnItemClickListener listener;

    // creating a constructor class for our adapter class.
    DeckRVAdapter() {
        super(DIFF_CALLBACK);
    }

    // creating a call back for item of recycler view.
    private static final DiffUtil.ItemCallback<DeckModal> DIFF_CALLBACK = new DiffUtil.ItemCallback<DeckModal>() {
        @Override
        public boolean areItemsTheSame(DeckModal oldItem, DeckModal newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(DeckModal oldItem, DeckModal newItem) {
            // below line is to check the course name, description and course duration.
            return oldItem.getDeckName().equals(newItem.getDeckName()) &&
                    oldItem.getdeckDescription().equals(newItem.getdeckDescription());
        }
    };

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // below line is use to inflate our layout file for each item of our recycler view.
        View item = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.course_rv_item, parent, false);
        return new ViewHolder(item);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DeckModal model = getItem(position);
        holder.courseNameTV.setText(model.getDeckName());
        holder.courseDescTV.setText(model.getdeckDescription());

        if (model.getImagePath() != null && !model.getImagePath().isEmpty()) {
            Glide.with(holder.itemView.getContext())
                    .load(model.getImagePath())
                    .into(holder.courseCoverIV);
        } else {
            holder.courseCoverIV.setImageResource(R.drawable.ic_android_black_24dp); // Placeholder image
        }
    }



    // creating a method to get course modal for a specific position.
    public DeckModal getCourseAt(int position) {
        return getItem(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        // view holder class to create a variable for each view.
        TextView courseNameTV, courseDescTV;
        ImageView courseCoverIV;  // Added ImageView for course cover

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing each view of our recycler view.
            courseNameTV = itemView.findViewById(R.id.idTVCourseName);
            courseDescTV = itemView.findViewById(R.id.idTVCourseDescription);

            courseCoverIV = itemView.findViewById(R.id.idIVCourseImage);  // Initialize the ImageView

            // adding on click listener for each item of recycler view.
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // inside on click listener we are passing position to our item of recycler view.
                    int position = getAdapterPosition();
                    if (listener != null && position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(getItem(position));
                    }
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(DeckModal model);
    }
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}
