package com.example.noteit;

import static com.example.noteit.NewDeckActivity.EXTRA_ID;
import static com.example.noteit.NewDeckActivity.EXTRA_NOTE_NAME;
import static com.example.noteit.NewDeckActivity.EXTRA_DESCRIPTION;
import static com.example.noteit.NewDeckActivity.EXTRA_IMAGE_PATH;

import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.roomtutorial.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView notesRV;
    private DeckRVAdapter adapter;
    private SearchView searchView;
    private static final int ADD_NOTE_REQUEST = 1;
    private static final int EDIT_NOTE_REQUEST = 2;
    private ViewModal viewmodal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchView = findViewById(R.id.search_view);
        notesRV = findViewById(R.id.idRVNotes);
        FloatingActionButton fab = findViewById(R.id.idFABAdd);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewDeckActivity.class);
                startActivityForResult(intent, ADD_NOTE_REQUEST);
            }
        });

        notesRV.setLayoutManager(new LinearLayoutManager(this));
        notesRV.setHasFixedSize(true);

        adapter = new DeckRVAdapter();
        notesRV.setAdapter(adapter);

        viewmodal = ViewModelProviders.of(this).get(ViewModal.class);

        viewmodal.getAllCourses().observe(this, new Observer<List<DeckModal>>() {
            @Override
            public void onChanged(List<DeckModal> models) {
                adapter.submitList(models);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                viewmodal.delete(adapter.getCourseAt(viewHolder.getAdapterPosition()));
                Toast.makeText(MainActivity.this, "Note deleted", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(notesRV);

        adapter.setOnItemClickListener(new DeckRVAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(DeckModal model) {
                // Create an intent to open NewDeckActivity
                Intent intent = new Intent(MainActivity.this, NewDeckActivity.class);

                // Pass the data to NewDeckActivity
                intent.putExtra(EXTRA_ID, model.getId());
                intent.putExtra(EXTRA_NOTE_NAME, model.getDeckName());
                intent.putExtra(EXTRA_DESCRIPTION, model.getdeckDescription());
                intent.putExtra(EXTRA_IMAGE_PATH, model.getImagePath()); // Add image path if needed

                // Start NewDeckActivity
                startActivityForResult(intent, EDIT_NOTE_REQUEST);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                performSearch(newText);
                return true;
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_NOTE_REQUEST && resultCode == RESULT_OK && data != null) {
            String noteName = data.getStringExtra(EXTRA_NOTE_NAME);
            String courseDescription = data.getStringExtra(EXTRA_DESCRIPTION);
            String imagePath = data.getStringExtra(EXTRA_IMAGE_PATH); // Retrieve the image path for a new course
            DeckModal model = new DeckModal(noteName, courseDescription, imagePath);
            viewmodal.insert(model);
            Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show();
        } else if (requestCode == EDIT_NOTE_REQUEST && resultCode == RESULT_OK && data != null) {
            int id = data.getIntExtra(EXTRA_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Note can't be updated", Toast.LENGTH_SHORT).show();
                return;
            }
            String noteName = data.getStringExtra(EXTRA_NOTE_NAME);
            String noteDesc = data.getStringExtra(EXTRA_DESCRIPTION);
            String imagePath = data.getStringExtra(EXTRA_IMAGE_PATH); // Retrieve the image path for an edited course
            DeckModal model = new DeckModal(noteName, noteDesc, imagePath);
            model.setId(id);
            viewmodal.update(model);
            Toast.makeText(this, "Note updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Note not saved", Toast.LENGTH_SHORT).show();
        }
    }


    // reference: I cant find the exact link but it was similar to this: https://developer.android.com/develop/ui/views/search/search-dialog
    private void performSearch(String query) {
        viewmodal.searchCourses("%" + query + "%").observe(this, new Observer<List<DeckModal>>() {
            @Override
            public void onChanged(List<DeckModal> models) {
                adapter.submitList(models);
            }
        });
    }


}
